"""
project1.py
DATA 612 - Project 1: Global Baseline Predictors and RMSE

Pipeline

Exposes: scaled_df, tickers, asset_classes, risk_profiles, prices,
         annualized_return, annualized_volatility, scores_df,
         baseline_matrix_reg, portfolio_weights, thresholds
"""

import numpy as np
import pandas as pd
import yfinance as yf
import requests
import os
from scipy.stats import zscore, rankdata
from yfinance import EquityQuery, screen

# ── Cache control ────────────────────────────────────────────
import pickle
import hashlib

CACHE_PATH = 'scripts/cache/project1_cache.pkl'
FORCE_REFRESH = False  # set to True to rerun the full pipeline

if not FORCE_REFRESH and os.path.exists(CACHE_PATH):
    print("Loading from cache...")
    with open(CACHE_PATH, 'rb') as f:
        cache = pickle.load(f)
    risk_profiles         = cache['risk_profiles']
    asset_classes         = cache['asset_classes']
    tickers               = cache['tickers']
    prices                = cache['prices']
    daily_returns         = cache['daily_returns']
    annualized_return     = cache['annualized_return']
    annualized_volatility = cache['annualized_volatility']
    scores_df             = cache['scores_df']
    scaled_df             = cache['scaled_df']
    thresholds            = cache['thresholds']
    train_matrix          = cache['train_matrix']
    test_matrix           = cache['test_matrix']
    global_mean           = cache['global_mean']
    user_bias             = cache['user_bias']
    item_bias             = cache['item_bias']
    baseline_matrix       = cache['baseline_matrix']
    baseline_matrix_reg   = cache['baseline_matrix_reg']
    portfolio_weights     = cache['portfolio_weights']
    portfolio_history     = cache['portfolio_history']
    portfolio_mc          = cache['portfolio_mc']
    history_df            = cache['history_df']
    train_pairs           = cache['train_pairs']
    test_pairs            = cache['test_pairs']
    print("Cache loaded. Pipeline skipped.")
else:
    print("Running full pipeline...")

    # ── Risk profiles ────────────────────────────────────────────
    risk_profiles = {
        'Conservative':          0.2,
        'Moderate_Conservative': 0.35,
        'Moderate':              0.5,
        'Moderate_Aggressive':   0.65,
        'Aggressive':            0.8,
        'Speculative':           1.0
    }

    # ── Base universe, manually curated ─────────────────────────
    asset_classes = {
        # Fixed Income
        'BND': 'Fixed Income', 'TLT': 'Fixed Income', 'IEF': 'Fixed Income',
        'SHY': 'Fixed Income', 'HYG': 'Fixed Income', 'LQD': 'Fixed Income',
        'EMB': 'Fixed Income', 'TIP': 'Fixed Income', 'MUB': 'Fixed Income',
        'AGG': 'Fixed Income', 'VCSH': 'Fixed Income', 'VCIT': 'Fixed Income',
        # Broad Market ETFs
        'SPY': 'Broad Market', 'VTI': 'Broad Market', 'IWM': 'Broad Market',
        'DIA': 'Broad Market', 'VTV': 'Broad Market', 'VUG': 'Broad Market',
        'SCHB': 'Broad Market',
        # International ETFs
        'VEA': 'International', 'VWO': 'International', 'EFA': 'International',
        'EEM': 'International', 'VXUS': 'International', 'IEMG': 'International',
        # Sector ETFs
        'XLK': 'Sectors', 'XLF': 'Sectors', 'XLE': 'Sectors',
        'XLV': 'Sectors', 'XLU': 'Sectors', 'XLP': 'Sectors',
        'XLI': 'Sectors', 'XLB': 'Sectors', 'XLRE': 'Sectors',
        # Commodities
        'GLD': 'Commodities', 'SLV': 'Commodities', 'USO': 'Commodities',
        'DBC': 'Commodities', 'IAU': 'Commodities', 'PDBC': 'Commodities',
        # Real Estate
        'VNQ': 'Real Estate', 'IYR': 'Real Estate', 'SCHH': 'Real Estate',
        # Aggressive / Thematic
        'QQQ': 'Thematic', 'ARKK': 'Thematic', 'ARKW': 'Thematic',
        'TQQQ': 'Thematic', 'SOXL': 'Thematic', 'BOTZ': 'Thematic',
        'ICLN': 'Thematic', 'HERO': 'Thematic', 'ARKG': 'Thematic',
        # Crypto Related
        'MSTR': 'Crypto', 'COIN': 'Crypto', 'IBIT': 'Crypto', 'FBTC': 'Crypto',
        }

    # ── Screener pull ────────────────────────────────────────────
    queries_to_run = [
        'most_actives',
        'growth_technology_stocks',
        'undervalued_large_caps',
        'undervalued_growth_stocks',
        'small_cap_gainers',
        'aggressive_small_caps',
        'top_etfs_us',
        'bond_etfs',
        'technology_etfs'
        ]

    all_symbols = {}

    for query_name in queries_to_run:
        query_body = yf.PREDEFINED_SCREENER_QUERIES[query_name]
        result = screen(
            query_body['query'],
            sortField=query_body['sortField'],
            size=100)   
        
        for q in result['quotes']:
            symbol = q['symbol']
            quote_type = q.get('quoteType', 'EQUITY')
            if symbol not in all_symbols:
                all_symbols[symbol] = quote_type

    # ── Merge screener into asset_classes ────────────────────────
    for symbol, quote_type in all_symbols.items():
        if symbol not in asset_classes:
            if quote_type == 'ETF':
                asset_classes[symbol] = 'ETF'
            elif quote_type == 'MUTUALFUND':
                asset_classes[symbol] = 'Mutual Fund'
            else:
                asset_classes[symbol] = 'Equity'

    tickers = list(asset_classes.keys())
    print(f"Total instruments: {len(tickers)}")

    # ── Historical price data ────────────────────────────────────
    raw_data = yf.download(
        tickers,
        start='2021-01-01',
        end=pd.Timestamp.today(),
        auto_adjust=True,
        threads=True)

    prices = raw_data['Close']
    print(f"Prices shape: {prices.shape}")

    # ── Returns and volatility ───────────────────────────────────
    daily_returns = prices.pct_change(fill_method=None).dropna(how='all')
    print(f"DEBUG daily_returns shape: {daily_returns.shape}")
    print(f"DEBUG daily_returns NaN count: {daily_returns.isna().sum().sum()}")
    
    # CAGR based on actual price change
    total_days = (~prices.isna()).sum()
    total_return = prices.iloc[-1] / prices.iloc[0]
    annualized_return = total_return ** (252 / total_days) - 1
    annualized_return = annualized_return.clip(-1, 10)

    annualized_volatility = daily_returns.std() * np.sqrt(252)

    print(f"Returns computed for {len(annualized_return)} instruments")


    # ── Suitability scores ───────────────────────────────────────
    raw_scores = {}

    for profile, weight in risk_profiles.items():
        raw_scores[profile] = (
            weight * annualized_return
            - (1 - weight) * annualized_volatility)

    scores_df = pd.DataFrame(raw_scores, index=tickers).T

    # ── Rank-based scaling ───────────────────────────────────────
    scaled_df = pd.DataFrame(
        index=scores_df.index,
        columns=scores_df.columns,
        dtype=float)

    for profile in scores_df.index:
        row = scores_df.loc[profile]
        valid = row.dropna()
        ranks = rankdata(valid, method='average')
        scaled = 1 + 4 * (ranks - 1) / (len(ranks) - 1)
        scaled_df.loc[profile, valid.index] = scaled

    print(f"Scaled score range: {scaled_df.min().min():.2f} to {scaled_df.max().max():.2f}")


    # ── Thresholding ─────────────────────────────────────────────
    thresholds = {
        'Conservative':          2.7,
        'Moderate_Conservative': 2.6,
        'Moderate':              2.5,
        'Moderate_Aggressive':   2.0,
        'Aggressive':            1.5,
        'Speculative':           2.0
    }

    for profile, threshold in thresholds.items():
        mask = scaled_df.loc[profile] < threshold
        scaled_df.loc[profile, mask] = np.nan

    print("Instruments per profile after thresholding:")
    for profile in scaled_df.index:
        count = scaled_df.loc[profile].notna().sum()
        print(f"  {profile:25s}: {count}/{len(tickers)}")

    # ── Train/test split ─────────────────────────────────────────
    np.random.seed(612)

    observed = [
        (user, item)
        for user in scaled_df.index
        for item in scaled_df.columns
        if not pd.isna(scaled_df.loc[user, item])
    ]

    np.random.shuffle(observed)
    split = int(len(observed) * 0.8)
    train_pairs = observed[:split]
    test_pairs  = observed[split:]

    train_matrix = pd.DataFrame(np.nan, index=scaled_df.index, columns=scaled_df.columns)
    test_matrix  = pd.DataFrame(np.nan, index=scaled_df.index, columns=scaled_df.columns)

    for user, item in train_pairs:
        train_matrix.loc[user, item] = scaled_df.loc[user, item]

    for user, item in test_pairs:
        test_matrix.loc[user, item] = scaled_df.loc[user, item]

    print(f"Observed ratings: {len(observed)}")
    print(f"Training:         {len(train_pairs)}")
    print(f"Test:             {len(test_pairs)}")

    # ── Global mean and biases ───────────────────────────────────
    global_mean = train_matrix.stack().mean()

    user_bias = train_matrix.mean(axis=1) - global_mean
    item_bias = train_matrix.mean(axis=0) - global_mean

    # ── Regularized biases ───────────────────────────────────────
    lambda_reg = {
        'Conservative':          25,
        'Moderate_Conservative': 20,
        'Moderate':              15,
        'Moderate_Aggressive':   10,
        'Aggressive':             5,
        'Speculative':            2
    }

    user_bias_reg = {}
    for profile, lam in lambda_reg.items():
        n_u   = train_matrix.loc[profile].count()
        sum_u = (train_matrix.loc[profile] - global_mean).sum()
        user_bias_reg[profile] = sum_u / (lam + n_u)

    user_bias_reg = pd.Series(user_bias_reg)

    item_bias_reg = {}
    for profile, lam in lambda_reg.items():
        n_i   = train_matrix.count(axis=0)
        sum_i = (train_matrix - global_mean).sum(axis=0)
        item_bias_reg[profile] = sum_i / (lam + n_i)

    print(f"Global mean: {global_mean:.4f}")
    print("User bias computed.")


    # ── Baseline predictor ───────────────────────────────────────
    baseline_matrix = pd.DataFrame(
        index=scaled_df.index,
        columns=scaled_df.columns,
        dtype=float
    )

    for user in scaled_df.index:
        for item in scaled_df.columns:
            u_bias = user_bias[user] if not pd.isna(user_bias[user]) else 0
            i_bias = item_bias[item] if not pd.isna(item_bias[item]) else 0
            baseline_matrix.loc[user, item] = np.clip(
                global_mean + u_bias + i_bias, 1, 5
            )

    # ── Regularized baseline predictor ───────────────────────────
    baseline_matrix_reg = pd.DataFrame(
        index=scaled_df.index,
        columns=scaled_df.columns,
        dtype=float
    )

    for user in scaled_df.index:
        for item in scaled_df.columns:
            u_bias = user_bias_reg[user] if not pd.isna(user_bias_reg[user]) else 0
            i_bias = item_bias_reg[user][item] if not pd.isna(item_bias_reg[user][item]) else 0
            baseline_matrix_reg.loc[user, item] = np.clip(
                global_mean + u_bias + i_bias, 1, 5
            )

    print("Baseline predictor computed.")
    print("Regularized baseline predictor computed.")

    # ── Portfolio weights ────────────────────────────────────────
    np.random.seed(612)
    n_simulations   = 1000
    forecast_days   = 252 * 5
    initial_capital = 1000

    portfolio_history = {}
    portfolio_mc      = {}
    portfolio_weights = {}

    for profile in risk_profiles:
        scores  = scaled_df.loc[profile].dropna()
        scores  = scores[scores >= thresholds[profile]]
        scores  = scores.nlargest(25)
        z_scores   = pd.Series(zscore(scores.values), index=scores.index)
        z_positive = z_scores - z_scores.min() + 1
        weights    = (z_positive ** 2) / (z_positive ** 2).sum()
        portfolio_weights[profile] = weights

        port_prices      = prices[weights.index]
        port_returns     = port_prices.pct_change(fill_method=None).fillna(0)
        weighted_returns = port_returns.dot(weights)
        portfolio_value  = initial_capital * (1 + weighted_returns).cumprod()
        portfolio_history[profile] = portfolio_value

        mean_ret = weighted_returns.mean()
        std_ret  = weighted_returns.std()

        simulations = np.zeros((n_simulations, forecast_days))
        for i in range(n_simulations):
            daily = np.random.normal(mean_ret, std_ret, forecast_days)
            simulations[i] = initial_capital * np.cumprod(1 + daily)

        portfolio_mc[profile] = simulations

    history_df = pd.DataFrame(portfolio_history)

    print("Portfolio weights computed.")
    print("Pipeline complete.")

    # ── Save cache ───────────────────────────────────────────────
    os.makedirs('scripts/cache', exist_ok=True)
    cache = {
        'risk_profiles':          risk_profiles,
        'asset_classes':          asset_classes,
        'tickers':                tickers,
        'prices':                 prices,
        'daily_returns':          daily_returns,
        'annualized_return':      annualized_return,
        'annualized_volatility':  annualized_volatility,
        'scores_df':              scores_df,
        'scaled_df':              scaled_df,
        'thresholds':             thresholds,
        'train_matrix':           train_matrix,
        'test_matrix':            test_matrix,
        'global_mean':            global_mean,
        'user_bias':              user_bias,
        'item_bias':              item_bias,
        'baseline_matrix':        baseline_matrix,
        'baseline_matrix_reg':    baseline_matrix_reg,
        'portfolio_weights':      portfolio_weights,
        'portfolio_history':      portfolio_history,
        'portfolio_mc':           portfolio_mc,
        'history_df':             history_df,
        'train_pairs':            train_pairs,
        'test_pairs':             test_pairs,
    }
    
    with open(CACHE_PATH, 'wb') as f:
        pickle.dump(cache, f)
    print("Cache saved.")

# ── Summary ──────────────────────────────────────────────────
print(f"\nProject 1 loaded successfully.")
print(f"  Instruments:      {len(tickers)}")
print(f"  Risk profiles:    {len(risk_profiles)}")
print(f"  Profiles:         {list(risk_profiles.keys())}")
print(f"  Global mean:      {global_mean:.4f}")
print(f"  Training ratings: {len(train_pairs)}")
print(f"  Test ratings:     {len(test_pairs)}")
print(f"  Portfolio tops:")
for profile in risk_profiles:
    top = list(portfolio_weights[profile].nlargest(3).index)
    print(f"    {profile:25s}: {top}")


# ── Exports ──────────────────────────────────────────────────
__all__ = [
    'risk_profiles',
    'asset_classes',
    'tickers',
    'prices',
    'daily_returns',
    'annualized_return',
    'annualized_volatility',
    'scores_df',
    'scaled_df',
    'thresholds',
    'train_matrix',
    'test_matrix',
    'global_mean',
    'user_bias',
    'item_bias',
    'baseline_matrix',
    'baseline_matrix_reg',
    'portfolio_weights',
    'portfolio_history',
    'portfolio_mc',
    'history_df',]


